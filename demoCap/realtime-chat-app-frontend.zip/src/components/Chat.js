import React from "react";

function Chat() {
  return (
    <div>
      <h2>Welcome to the Chat Room</h2>
    </div>
  );
}

export default Chat;
